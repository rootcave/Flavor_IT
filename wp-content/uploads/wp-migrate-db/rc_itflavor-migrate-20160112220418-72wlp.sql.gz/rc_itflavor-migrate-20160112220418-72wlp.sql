# WordPress MySQL database migration
#
# Generated: Tuesday 12. January 2016 22:04 UTC
# Hostname: localhost
# Database: `rc_itflavor`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';

