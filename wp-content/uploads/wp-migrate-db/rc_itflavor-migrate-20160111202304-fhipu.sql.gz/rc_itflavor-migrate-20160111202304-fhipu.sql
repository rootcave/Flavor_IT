# WordPress MySQL database migration
#
# Generated: Monday 11. January 2016 20:23 UTC
# Hostname: localhost
# Database: `rc_itflavor`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';

